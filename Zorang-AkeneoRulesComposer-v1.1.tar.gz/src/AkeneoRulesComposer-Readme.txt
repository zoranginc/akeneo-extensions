Installation Instructions:
 
1) Unzip and untar the fileZorang-AkeneoRulesComposer-v1.0.tar.gz in Akeneo home directory. It will create the folder "${akeneo-home}/src/Zorang/Bundle/AkeneoRulesComposer"

2) Register it into AppKernel.php:

# ${akeneo-home}/app/AppKernel.php

class AppKernel extends OroKernel
{
    /**
     * {@inheritdoc}
     */
    public function registerBundles()
    {
        $bundles = [
            // your app bundles should be registered here
            new Zorang\Bundle\AkeneoRulesComposer\ZorangAkeneoRulesComposer(),
        ];
    }
}

3) Add the bundle resources in app/config/routing.yml:
# ${akeneo-home}/app/config/routing.yml

pim_custom_catalog_rule:
    resource: "@ZorangAkeneoRulesComposer/Resources/config/routing.yml"

4) Change rule file name,log name in config_rule.yml (if required)
# ${akeneo-home}/src/Zorang/Bundle/AkeneoRulesComposer/Resources/config/config_rule.yml

parameters:
    rule_file: rules.yml
    rule_file_path: /tmp/rulesfiles
    php_bin: /usr/bin/php
    logfile: importrules.log

5) Clear cache:
php app/console cache:clear --env=prod


