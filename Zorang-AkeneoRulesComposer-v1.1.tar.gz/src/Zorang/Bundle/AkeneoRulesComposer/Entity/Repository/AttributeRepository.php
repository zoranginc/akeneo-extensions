<?php
/**
 * Copyright (c) 2017, Zorang, Inc., All Rights Reserved
 * This code is owned by Zorang, Inc. and unauthorized copying and distribution of code is prohibited
 * The use of this code for commercial purpose without written permission from Zorang, Inc. is not permitted.
 * Author: Zorang, Inc.
 * Bundle: Akeneo Rule Composer v1.0
 */
namespace Zorang\Bundle\AkeneoRulesComposer\Entity\Repository;

use Pim\Bundle\CatalogBundle\Doctrine\ORM\Repository\AttributeRepository as BaseAttributeRepository;

class AttributeRepository extends BaseAttributeRepository
{

    /**
     * {@inheritdoc}
     */
    public function findAttributeCodesTypes()
    {
        $attributeTypeEntity = $this->getAkeneoVersion();
        $codes = $this
            ->createQueryBuilder('a')
            ->select('a.code, a.'.$attributeTypeEntity)
            ->getQuery()
            ->getArrayResult();

        return array_map(
            function ($data) {
                return $data['code'] . '/' . substr($data[$this->getAkeneoVersion()], 12);
            },
            $codes
        );
    }
    public function findAttributeLocalScope()
    {
        $codes = $this
            ->createQueryBuilder('a')
            ->select('a.code, a.'.$this->getAkeneoVersion().',CASE WHEN a.localizable = 1  then 1 else 0 end as localizable,CASE  WHEN a.scopable = 1  then 1 else 0 end as scopable' )
            ->getQuery()
            ->getArrayResult();

        return array_map(
            function ($data) {
                return $data['code'] . '/' . substr($data[$this->getAkeneoVersion()], 12)."/locale:".$data['localizable']."/scope:".$data['scopable'];
            },
            $codes
        );
    }

    public function findAttributeCodes()
    {

        $attributeTypeEntity = $this->getAkeneoVersion();
        $codes = $this
            ->createQueryBuilder('a')
            ->select('a.code, a.'.$attributeTypeEntity)
            ->orderBy('a.code')
            ->getQuery()
            ->getArrayResult();

        return array_map(
            function ($data) {
                    return $data['code'] . '/' . substr($data[$this->getAkeneoVersion()], 12);
            },
            $codes
        );
    }

    // For currency or price attribute
    public function findAttributeTypeByCode($code)
    {
        $codes = $this
            ->createQueryBuilder('a')
            ->select('a.'.$this->getAkeneoVersion().', CASE  WHEN a.localizable = 1 AND a.scopable = 1 then 1 else CASE WHEN a.localizable = 1 AND a.scopable = 0 THEN 2 ELSE CASE WHEN a.localizable = 0 AND a.scopable = 1 THEN 3 ELSE 0 end end end as status, a.id as id')
            ->where('a.code = :code')
            ->setParameter(':code', $code)
            ->getQuery()
            ->getArrayResult();
        return $codes;
    }

    //for getting attribute code type value for isscopable and islocalizable
    public function findScopeLocaleAttributeCodesTypes()
    {
        $codes = $this
            ->createQueryBuilder('a')
            ->select('a.code, a.'.$this->getAkeneoVersion().', CASE  WHEN a.localizable = 1 AND a.scopable = 1 then 1 else CASE WHEN a.localizable = 1 AND a.scopable = 0 THEN 2 ELSE CASE WHEN a.localizable = 0 AND a.scopable = 1 THEN 3 ELSE 0 end end end as status, a.id as id')
            ->getQuery()
            ->getArrayResult();

        return array_map(
            function ($data) {
                return $data['code'] . '/' . substr($data[$this->getAkeneoVersion()], 12) . '/' .$data['status'].'/'.$data['id'];
            },
            $codes
        );
    }

    public function findScopeLocalActionAttributeCodes()
    {
        $codes = $this
            ->createQueryBuilder('a')
            ->select('a.code, a.'.$this->getAkeneoVersion().',CASE  WHEN a.localizable = 1 AND a.scopable = 1 then 1 else CASE WHEN a.localizable = 1 AND a.scopable = 0 THEN 2 ELSE CASE WHEN a.localizable = 0 AND a.scopable = 1 THEN 3 ELSE 0 end end end as status, a.id as id')
            ->orderBy('a.code')
            ->getQuery()
            ->getArrayResult();

        return array_map(
            function ($data) {
                return $data['code']. '/' . substr($data[$this->getAkeneoVersion()],12).'/'. $data['status'].'/'. $data['id'];
            },
            $codes
        );
    }

    public function getAttributeIDfromCode($code)
    {
        $codes = $this
            ->createQueryBuilder('a')
            ->select('a.id')
            ->where('a.code = :code')
            ->setParameter(':code', $code)
            ->getQuery()
            ->getArrayResult();

        if(isset($codes[0]['id']))
        {
            $id = $codes[0]['id'];

            $em=$this->getEntityManager();
            $connection = $em->getConnection();
            $statement = $connection->prepare(
                'select code as code  from pim_catalog_attribute_option where attribute_id='.$id
            );

            $statement->execute();
            $result = $statement->fetchAll();
            return $result;
        }
        else{
            return null;
        }

    }
    public function getAllAttributeOptions()
    {
        $em=$this->getEntityManager();
        $connection = $em->getConnection();
        $statement = $connection->prepare(
            'select code as code, attribute_id as attribute_id from pim_catalog_attribute_option'
        );

        $statement->execute();
        $result = $statement->fetchAll();
        return $result;
    }

    //get Akeneo Version
    public function getAkeneoVersion()
    {
        $version = 6;
        $fname = __DIR__ . '/../../../../../../composer.lock';
        $myfile = fopen($fname, "r") or die("Unable to open file!");
        // Output one line until end-of-file
        while(!feof($myfile)) {
            $line= fgets($myfile);
            //if(preg_match('(akeneo|pim)', $line) === 1) {
               // $AkeneoVer = fgets($myfile);
            if(preg_match('(akeneo/pim*)', $line) === 1) {
                if (preg_match('(~1.)', $line) === 1) {
                    $AkeneoVer = $line;
                } else {
                    $AkeneoVer = fgets($myfile);
                }
                $AkeneoVer = explode(":", $AkeneoVer);
                if (isset($AkeneoVer[1])) {
                    $AkeneoVer = str_replace('"', '', $AkeneoVer[1]);
                    $AkeneoVer = str_replace(',', '', $AkeneoVer);
                    $AkeneoVer = explode(".", $AkeneoVer);
                    if (isset($AkeneoVer[1])) {
                        $version = $AkeneoVer[1];
                    }
                    //echo "Version: ".$AkeneoVer."<br>";
                }
                //echo $line;
                break;
            }
        }
        fclose($myfile);
        if($version == 6)
        {
            return 'attributeType';
        }
        else
        {
            return 'type';
        }
    }
}
