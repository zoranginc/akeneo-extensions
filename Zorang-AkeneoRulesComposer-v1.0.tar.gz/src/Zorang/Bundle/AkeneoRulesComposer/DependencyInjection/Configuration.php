<?php
/**
 * Copyright (c) 2017, Zorang, Inc., All Rights Reserved
 * This code is owned by Zorang, Inc. and unauthorized copying and distribution of code is prohibited
 * The use of this code for commercial purpose without written permission from Zorang, Inc. is not permitted.
 * Author: Zorang, Inc.
 * Bundle: Akeneo Rule Composer v1.0
 */
namespace Zorang\Bundle\AkeneoRulesComposer\DependencyInjection;

use Symfony\Component\Config\Definition\Builder\TreeBuilder;
use Symfony\Component\Config\Definition\ConfigurationInterface;


class Configuration implements ConfigurationInterface
{
    /**
     * {@inheritDoc}
     */
    public function getConfigTreeBuilder()
    {
        $treeBuilder = new TreeBuilder();
        $rootNode = $treeBuilder->root('catalog_rule');

        // Here you should define the parameters that are allowed to
        // configure your bundle. See the documentation linked above for
        // more information on that topic.

        return $treeBuilder;
    }
}
