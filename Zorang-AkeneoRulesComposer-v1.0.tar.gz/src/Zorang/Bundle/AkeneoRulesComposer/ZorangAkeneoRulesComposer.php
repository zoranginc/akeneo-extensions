<?php
/**
 * Copyright (c) 2017, Zorang, Inc., All Rights Reserved
 * This code is owned by Zorang, Inc. and unauthorized copying and distribution of code is prohibited
 * The use of this code for commercial purpose without written permission from Zorang, Inc. is not permitted.
 * Author: Zorang, Inc.
 * Bundle: Akeneo Rule Composer v1.0
 */
namespace Zorang\Bundle\AkeneoRulesComposer;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ZorangAkeneoRulesComposer extends Bundle
{
    public function getParent()
    {
        return 'PimEnterpriseCatalogRuleBundle';

    }
}
