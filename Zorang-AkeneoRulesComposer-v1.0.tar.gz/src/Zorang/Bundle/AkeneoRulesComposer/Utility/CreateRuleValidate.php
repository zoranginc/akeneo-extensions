<?php
/**
 * Copyright (c) 2017, Zorang, Inc., All Rights Reserved
 * This code is owned by Zorang, Inc. and unauthorized copying and distribution of code is prohibited
 * The use of this code for commercial purpose without written permission from Zorang, Inc. is not permitted.
 * Author: Zorang, Inc.
 * Bundle: Akeneo Rule Composer v1.0
 */

namespace Zorang\Bundle\AkeneoRulesComposer\Utility;


class CreateRuleValidate
{
    public function validate($arraydata)
    {
        $error="";
        $dataarray = explode("&", $arraydata);
        $code=$dataarray[0];

        if(stripos($code,"=code")!==false
           // ||stripos($code,"code")!==false
            ||stripos($code,"priority")!==false
            ||stripos($code,"category")!==false
            ||stripos($code,"family")!==false
            || stripos($code,"field")!==false
            ||stripos($code,"fields")!==false
            ||stripos($code,"operator")!==false
            ||stripos($code,"value")!==false
            ||stripos($code,"actionsfield")!==false
            || stripos($code,"actionsvalue")!==false
            ||stripos($code,"actions")!==false
            ||stripos($code,"actionssrc")!==false
            ||stripos($code,"actionstarget")!==false


        ){
            $error=$error."Rule code doesnot accept any of the field names code,category,family,field,operator,value,actions...etc\n";
            $error=$error."Please give a valid rule code \n";
            return $error;
        }
        if(stripos($arraydata,"zorang_rule[actions")===false){
            $error="Please add a valid actions to create rule \n";
            return $error;
        }
        /*if(stripos($arraydata,"zorang_rule[fields][value")!==false){
            $start=stripos($arraydata,"[fields][value");

            $end = stripos($arraydata, 'zorang_rule[actions1]', 1);
            $end=$end-$start;

            $condnValue=substr($arraydata,$start,$end);
            $values=explode("&",$condnValue);
            if (stripos($condnValue," ,")!==false
                || stripos($condnValue,", ")!==false
                || stripos($condnValue," , ")!==false
                || stripos($condnValue," :")!==false
                || stripos($condnValue,": ")!==false
                || stripos($condnValue," : ")!==false
                || stripos($condnValue,"= ")!==false
                || stripos($condnValue," &")!==false
                || stripos($condnValue,"; ")!==false
                || stripos($condnValue," ; ")!==false
                || stripos($condnValue," ;")!==false
                || stripos($condnValue,"$ ")!==false
                || stripos($condnValue," $ ")!==false
                || stripos($condnValue," $")!==false
            ){

                $error = "Please remove the unwanted space in conditions value"  . "\n";
                return $error;


            }if (stripos($condnValue,"\"")!==false
                || stripos($condnValue,"\'")!==false
            ){

                $error = "Please remove quotes in conditions value"  . "\n";
                return $error;


            }
        }*/
        return $error;

    }
}